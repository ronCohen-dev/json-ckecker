package com.system.bank.task.module.controllers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.system.bank.task.Services.CustomerService;
import com.system.bank.task.exception.CustomerExseption;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.io.FileNotFoundException;

@RestController
@RequiredArgsConstructor
@RequestMapping("Api/customer")

public class CustomerController {

    private final CustomerService customerService;

    @PostMapping

    public String addCustomer(@RequestBody String c) throws CustomerExseption, FileNotFoundException, JsonProcessingException {

            return customerService.checkCustomerJson(c);

    }
}
