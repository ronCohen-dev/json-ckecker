package com.system.bank.task.exception;

import java.io.FileNotFoundException;
import java.util.logging.ErrorManager;

public class CustomerExseption  extends Exception {

    public CustomerExseption (ErrorMassage e){
        super (e.getDesc());
    }
}
